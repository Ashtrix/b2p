package com.example.b2p;
import android.content.pm.ApplicationInfo;
import android.view.View;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity {
    private Context mContext;
    private Activity mActivity;

    private Button Textbutton;
    private TextView mTextView;
    private TextView lTextView;

    int count=0;
    String tempstr="";
    PackageManager packageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void scrollButton(View view){
        // Get the application context
        mContext = getApplicationContext();
        mActivity = MainActivity.this;

        // Get the widgets reference from xml layout
        Textbutton = findViewById(R.id.button);
        mTextView = findViewById(R.id.text_view);
        lTextView=findViewById(R.id.textView);
        Textbutton.setVisibility(view.GONE);
        lTextView.setVisibility(view.GONE);
        mTextView.setVisibility(view.VISIBLE);
        mTextView.setMovementMethod(new ScrollingMovementMethod());

        List<String> installedPackageNames = new ArrayList<String>();
        List<String> name = new ArrayList<String>();
        PackageManager packageManager= getApplicationContext().getPackageManager();
        List<ApplicationInfo> apps = getPackageManager().getInstalledApplications(0);
        for(ApplicationInfo app : apps) {
            if ((app.flags & (ApplicationInfo.FLAG_UPDATED_SYSTEM_APP | ApplicationInfo.FLAG_SYSTEM)) > 0) {
                // It is a system app
            } else {
                installedPackageNames.add(app.packageName);
            }
        }
        TextView text = (TextView) findViewById(R.id.text_view);
        String key="";
//        int count[] = new int[100];
//        for(int i=0;i<installedPackageNames.size();i++) {
//            for (int j = 0; j < installedPackageNames.get(i).length(); j++) {
//                if (installedPackageNames.get(i).charAt(j) == '.') {
//                    count[i]=0;
//                }
//            }
//        }

        int count[] = new int[100];
        List<String> actualpermission = new ArrayList<String>();

        int j=0;
        int i=0;
        for(j=0;j<installedPackageNames.size();j++)
        {
        Log.i("messa",Integer.toString(getPermissionsByPackageName(installedPackageNames.get(j)).length()));
        for(i=0;i<getPermissionsByPackageName(installedPackageNames.get(j)).length();i++) {

            if (getPermissionsByPackageName(installedPackageNames.get(j)).charAt(i) != '\n' && getPermissionsByPackageName(installedPackageNames.get(j)).charAt(i) != '\0') {
                tempstr = tempstr + getPermissionsByPackageName(installedPackageNames.get(j)).charAt(i);
            } else {
                // for (; getPermissionsByPackageName(installedPackageNames.get(0)).charAt(i) != 'a' || getPermissionsByPackageName(installedPackageNames.get(0)).charAt(i) != 'c' || getPermissionsByPackageName(installedPackageNames.get(0)).charAt(i) != '\0'; i++) {}
                if (tempstr.equals("android.permission.BLUETOOTH")) {
                    tempstr = "Bluetooth";
                } else if (tempstr.equals("android.permission.RECORD_AUDIO")) {
                    tempstr = "Microphone";
                } else if (tempstr.equals("android.permission.CAMERA")) {
                    tempstr = "Camera";
                } else if (tempstr.equals("android.permission.ACCESS_COARSE_LOCATION") || tempstr.equals("android.permission.ACCESS_FINE_LOCATION")) {
                    tempstr = "Location";
                } else if (tempstr.equals("android.permission.READ_EXTERNAL_STORAGE") || tempstr.equals("android.permission.WRITE_EXTERNAL_STORAGE")) {
                    tempstr = "File storage";
                } else if (tempstr.equals("android.permission.READ_CONTACTS") || tempstr.equals("android.permission.WRITE_CONTACTS")) {
                    tempstr = "Contacts";
                } else if (tempstr.equals("android.permission.CALL_PHONE") || tempstr.equals("android.permission.READ_PHONE_STATE") || tempstr.equals("android.permission.READ_CALL_LOG") || tempstr.equals("android.permission.WRITE_CALL_LOG")) {
                    tempstr = "Telephone";
                } else if (tempstr.equals("android.permission.SEND_SMS") || tempstr.equals("android.permission.RECEIVE_SMS") || tempstr.equals("android.permission.READ_SMS") || tempstr.equals("android.permission.RECEIVE_MMS")) {
                    tempstr = "Sms";
                } else {
                    tempstr = "";
                    continue;
                }

                // for(;getPermissionsByPackageName(installedPackageNames.get(0)).charAt(i) != 'a' || getPermissionsByPackageName(installedPackageNames.get(0)).charAt(i) != 'c' || getPermissionsByPackageName(installedPackageNames.get(0)).charAt(i) != '\0';i++);

                actualpermission.add(tempstr);
                Log.i("permis", tempstr);
                tempstr = "";
            }

        }
            getWebsite(installedPackageNames.get(j));
        }
        Log.i("ivar",Integer.toString(i));
//            while() {
//
//                String[] st1 = getPermissionsByPackageName(installedPackageNames.get(i)).split("\n");
////                for (int j = 0; j < installedPackageNames.get(i).length(); j++) {
////                    if (installedPackageNames.get(i).charAt(j) == '.') {
////                        count[i]++;
////                    }
// //               }
//            }



//        for( i=0;i<installedPackageNames.size();i++) {
//           // String[] str;
//            //str = installedPackageNames.get(i).split(Pattern.quote("."));
//            //key +=   "\n" + getPermissionsByPackageName(installedPackageNames.get(i)) + "\n";
//            getWebsite(installedPackageNames.get(i));
//        }



        //getWebsite();
        //text.setText(key);
    }


    private void getWebsite(final String str) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final StringBuilder builder = new StringBuilder();

                try {
                    Document doc = Jsoup.connect("https://play.google.com/store/apps/details?id=" + str + "&hl=en_IN").get();
                    String title = doc.title();
                    //Sting genre=
                   // Element link = doc.select("a[itemprop=genre]").first();
                    Elements link= doc.select("h1[itemprop=name]");
//                    String str1[];
//                    str1 = title.split("-");
                    //title=str1[0];
                    builder.append(link.text()).append("\n");



                    //builder.append("\n").append("Link : ").append(link.attr("meta[itemprop]"))
                    //builder.append("\n").append("Catogory: ").append(link.text());
                    builder.append(getPermissionsByPackageName(str)).append("\n");
                } catch (IOException e) {
                    //builder.append("Error : ").append(e.getMessage()).append("\n");
                }
                count++;
                Log.i("count",Integer.toString(count));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                       mTextView.append(builder.toString() +"\n"+ tempstr );

                    }
                });

            }
        }).start();
    }
    // Custom method to get all installed package names
    protected HashMap<String,String> getInstalledPackages(){
        PackageManager packageManager = getPackageManager();

        // Initialize a new intent
        Intent intent = new Intent(Intent.ACTION_MAIN,null);
        // Set the intent category
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        // Set the intent flags
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                |Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

        // Initialize a new list of resolve info
        List<ResolveInfo> resolveInfoList = getPackageManager().queryIntentActivities(intent,0);

        // Initialize a new hash map of package names and application label
        HashMap<String,String> map = new HashMap<>();

        // Loop through the resolve info list
        for(ResolveInfo resolveInfo : resolveInfoList){
            // Get the activity info from resolve info
            ActivityInfo activityInfo = resolveInfo.activityInfo;

            // Get the package name
            String packageName = activityInfo.applicationInfo.packageName;

            // Get the application label
            String label = (String) packageManager.getApplicationLabel(activityInfo.applicationInfo);

            // Put the package name and application label to hash map
            map.put(packageName,label);
        }
        return map;
    }


    // Custom method to get app requested and granted permissions from package name
    protected String getPermissionsByPackageName(String packageName){
        // Initialize a new string builder instance
        StringBuilder builder = new StringBuilder();

        try {
            // Get the package info
            PackageInfo packageInfo = getPackageManager().getPackageInfo(packageName, PackageManager.GET_PERMISSIONS);

            // Permissions counter
            //int counter = 1;

            /*
                PackageInfo
                    Overall information about the contents of a package. This corresponds to all of
                    the information collected from AndroidManifest.xml.
            */
            /*
                String[] requestedPermissions
                    Array of all <uses-permission> tags included under <manifest>, or null if there
                    were none. This is only filled in if the flag GET_PERMISSIONS was set. This list
                    includes all permissions requested, even those that were not granted or known
                    by the system at install time.
            */
            /*
                int[] requestedPermissionsFlags
                    Array of flags of all <uses-permission> tags included under <manifest>, or null
                    if there were none. This is only filled in if the flag GET_PERMISSIONS was set.
                    Each value matches the corresponding entry in requestedPermissions, and will
                    have the flag REQUESTED_PERMISSION_GRANTED set as appropriate.
            */
            /*
                int REQUESTED_PERMISSION_GRANTED
                    Flag for requestedPermissionsFlags: the requested permission is currently
                    granted to the application.
        */

            // Loop through the package info requested permissions
            for (int i = 0; i < packageInfo.requestedPermissions.length; i++) {
                if ((packageInfo.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) {
                    String permission =packageInfo.requestedPermissions[i];
                    // To make permission name shorter
                    //permission = permission.substring(permission.lastIndexOf(".")+1);
                    builder.append(permission + "\n");
                    //counter++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return builder.toString();
    }
}